<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");

$conn = new mysqli("localhost", "root", "", "lorilah");
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "DB connection failed"]);
    exit;
}

$truckName = isset($_GET['name']) ? $conn->real_escape_string($_GET['name']) : '';
if (empty($truckName)) {
    echo json_encode(["status" => "error", "message" => "Missing name"]);
    exit;
}

$sql = "
    SELECT reported_by, reported_at 
    FROM report_form 
    WHERE foodtruck_name = '$truckName' 
    ORDER BY reported_at DESC 
    LIMIT 1
";

$result = $conn->query($sql);
if ($row = $result->fetch_assoc()) {
    echo json_encode([
        "status" => "success",
        "reported_by" => $row['reported_by'],
        "reported_at" => $row['reported_at']
    ]);
} else {
    echo json_encode(["status" => "success", "reported_by" => "Unknown", "reported_at" => "N/A"]);
}

$conn->close();
?>
