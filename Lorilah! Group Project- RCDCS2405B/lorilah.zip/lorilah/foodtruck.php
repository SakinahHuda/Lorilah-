<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lorilah";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Database connection failed.");
}

$foodtrucks = [];
$reportedTrucks = [];

// Load from foodtrucks table
$result1 = $conn->query("SELECT name, foodtype, address, latitude, longitude FROM foodtrucks");
if ($result1 && $result1->num_rows > 0) {
    while ($row = $result1->fetch_assoc()) {
        $foodtrucks[] = $row;
    }
}

// Load from report_form table
$result2 = $conn->query("SELECT foodtruck_name AS name, foodtype, location_description AS address, latitude, longitude FROM report_form");
if ($result2 && $result2->num_rows > 0) {
    while ($row = $result2->fetch_assoc()) {
        $reportedTrucks[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LoriLah! - Foodtruck Management</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        #map {
            height: 400px;
            width: 100%;
            margin-bottom: 20px;
        }
        .section {
            margin-top: 20px;
        }
        .table-section, .add-section {
            display: none;
            margin-top: 20px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="index.php">LoriLah!</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="user.php">User</a></li>
                <li class="nav-item"><a class="nav-link active" href="foodtruck.php">Foodtruck</a></li>
                <li class="nav-item"><a class="nav-link" href="signup.php">Sign Up</a></li>
                <li class="nav-item" id="loginLink"><a class="nav-link" href="login.php">Login</a></li>
                <li class="nav-item d-none" id="logoutLink"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">

    <h3>Food Truck Locations</h3>
    <div id="map"></div>

    <div class="section mb-4">
        <h4>Manage Foodtrucks</h4>
        <select id="actionSelect" class="form-select">
            <option value="">-- Select Action --</option>
            <option value="view">View Foodtruck Locations</option>
            <option value="add">Add New Foodtruck</option>
        </select>
    </div>

    <div class="table-section">
        <h5>Foodtruck Locations</h5>
        <table class="table table-bordered table-striped">
            <thead class="table-primary">
                <tr>
                    <th>Name</th>
                    <th>Food Type</th>
                    <th>Address</th>
                    <th>Coordinate (Lat, Lng)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($foodtrucks as $truck): ?>
                    <tr>
                        <td><?= htmlspecialchars($truck['name']) ?></td>
                        <td><?= htmlspecialchars($truck['foodtype']) ?></td>
                        <td><?= htmlspecialchars($truck['address']) ?></td>
                        <td><?= $truck['latitude'] ?>, <?= $truck['longitude'] ?></td>
                    </tr>
                <?php endforeach; ?>

                <?php foreach ($reportedTrucks as $truck): ?>
                    <tr class="table-warning">
                        <td><?= htmlspecialchars($truck['name']) ?> (User Report)</td>
                        <td><?= htmlspecialchars($truck['foodtype']) ?></td>
                        <td><?= htmlspecialchars($truck['address']) ?></td>
                        <td><?= $truck['latitude'] ?>, <?= $truck['longitude'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="add-section">
        <h5>Add New Foodtruck</h5>
        <form action="process_add_foodtruck.php" method="POST">
            <div class="mb-3">
                <label for="truckName" class="form-label">Truck Name</label>
                <input type="text" class="form-control" id="truckName" name="truckName" placeholder="Enter truck name" required>
            </div>
            <div class="mb-3">
                <label for="foodtype" class="form-label">Food Type</label>
                <input type="text" class="form-control" id="foodtype" name="foodtype" placeholder="Enter food type" required>
            </div>
            <div class="mb-3">
                <label for="owner" class="form-label">Owner Name</label>
                <input type="text" class="form-control" id="owner" name="owner" placeholder="Enter owner's name" required>
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Truck Address</label>
                <input type="text" class="form-control" id="address" name="address" placeholder="Enter truck address" required>
            </div>
            <button type="submit" class="btn btn-success">Submit</button>
        </form>
    </div>

</div>

<script>
if (sessionStorage.getItem('isLoggedIn') === 'true') {
    document.getElementById('loginLink').style.display = 'none';
    document.getElementById('logoutLink').classList.remove('d-none');
}

function logout() {
    sessionStorage.removeItem('isLoggedIn');
    window.location.href = 'logout.php';
}

function initMap() {
    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 6,
        center: { lat: 4.5, lng: 101.0 }
    });

    const staticFoodTrucks = [
        { lat: 3.139, lng: 101.6869, name: "Burger Truck (KL)", foodtype: "Western" },
        { lat: 3.150, lng: 101.682, name: "Roti John Truck (KL)", foodtype: "Local" },
        { lat: 1.4927, lng: 103.7414, name: "Johor Mee Rebus Truck", foodtype: "Local" },
        { lat: 2.7258, lng: 101.9381, name: "Negeri Sembilan Lemang Truck", foodtype: "Traditional" },
        { lat: 3.8126, lng: 103.3256, name: "Pahang Satay Tempoyak Truck", foodtype: "Traditional" },
        { lat: 5.4164, lng: 100.3327, name: "Penang Char Koay Teow Truck", foodtype: "Local" },
        { lat: 6.1210, lng: 100.3670, name: "Kedah Laksa Utara Truck", foodtype: "Local" },
        { lat: 6.4447, lng: 100.1987, name: "Perlis Roti Canai Truck", foodtype: "Local" },
        { lat: 4.5975, lng: 101.0901, name: "Perak Nasi Ganja Truck", foodtype: "Local" },
        { lat: 2.1896, lng: 102.2501, name: "Melaka Asam Pedas Truck", foodtype: "Local" },
        { lat: 6.1254, lng: 102.2381, name: "Kelantan Nasi Kerabu Truck", foodtype: "Local" },
        { lat: 5.3302, lng: 103.1408, name: "Terengganu Keropok Lekor Truck", foodtype: "Local" },
        { lat: 2.9264, lng: 101.6964, name: "Putrajaya Cucur Udang Truck", foodtype: "Snack" }
    ];

    staticFoodTrucks.forEach(truck => {
        new google.maps.Marker({
            position: { lat: truck.lat, lng: truck.lng },
            map,
            title: `${truck.name} (${truck.foodtype})`
        });
    });

    const foodTrucks = <?= json_encode($foodtrucks) ?>;
    const reportedTrucks = <?= json_encode($reportedTrucks) ?>;

    foodTrucks.forEach(truck => {
        if (truck.latitude && truck.longitude) {
            new google.maps.Marker({
                position: { lat: parseFloat(truck.latitude), lng: parseFloat(truck.longitude) },
                map,
                title: `${truck.name} (${truck.foodtype}) - ${truck.address}`
            });
        }
    });

    reportedTrucks.forEach(truck => {
        if (truck.latitude && truck.longitude) {
            new google.maps.Marker({
                position: { lat: parseFloat(truck.latitude), lng: parseFloat(truck.longitude) },
                map,
                icon: "http://maps.google.com/mapfiles/ms/icons/yellow-dot.png",
                title: `${truck.name} (${truck.foodtype}) - ${truck.address}`
            });
        }
    });
}

document.getElementById("actionSelect").addEventListener("change", function() {
    const selected = this.value;
    document.querySelector(".table-section").style.display = selected === "view" ? "block" : "none";
    document.querySelector(".add-section").style.display = selected === "add" ? "block" : "none";
});
</script>

<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD2cmnlJ-URB99rPfLKsLqn2qpj-cYTELU&callback=initMap"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

<?php $conn->close(); ?>
