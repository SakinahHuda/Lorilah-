<?php
include 'db.php';
session_start();

if (!isset($_GET['id'])) {
    header("Location: user.php");
    exit();
}

$id = intval($_GET['id']);
$error = "";
$success = "";

// Fetch existing user data
$result = $conn->query("SELECT * FROM users WHERE id = $id");

if ($result->num_rows === 0) {
    header("Location: user.php");
    exit();
}

$user = $result->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $conn->real_escape_string($_POST['fullname']);
    $email = $conn->real_escape_string($_POST['email']);
    $address = $conn->real_escape_string($_POST['address']);
    $latitude = floatval($_POST['latitude']);
    $longitude = floatval($_POST['longitude']);

    $update = $conn->query("UPDATE users SET fullname='$fullname', email='$email', address='$address', latitude=$latitude, longitude=$longitude WHERE id=$id");

    if ($update) {
        $success = "User information updated successfully.";
        header("Location: user.php");
        exit();
    } else {
        $error = "Failed to update user.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit User - LoriLah!</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2>Edit User</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" name="fullname" class="form-control" value="<?= htmlspecialchars($user['fullname']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Location</label>
            <input type="text" name="address" class="form-control" value="<?= htmlspecialchars($user['address']) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Latitude</label>
            <input type="text" name="latitude" class="form-control" value="<?= htmlspecialchars($user['latitude']) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Longitude</label>
            <input type="text" name="longitude" class="form-control" value="<?= htmlspecialchars($user['longitude']) ?>">
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
        <a href="user.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

</body>
</html>
