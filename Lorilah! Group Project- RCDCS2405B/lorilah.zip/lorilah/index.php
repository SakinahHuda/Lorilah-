<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LoriLah! - Home</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .hero {
            width: 100%;
            height: 100vh;
            background: url('loginfoodtruck.jpg') center center/cover no-repeat;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            color: white;
            text-shadow: 2px 2px 5px rgba(0,0,0,0.7);
            position: relative;
        }

        .welcome-container {
            background-color: rgba(0, 0, 0, 0.6);
            padding: 40px;
            border-radius: 20px;
            text-align: center;
            max-width: 600px;
            width: 90%;
            backdrop-filter: blur(5px);
        }

        .welcome-container h1 {
            color: #fff;
            font-size: 3rem;
            font-weight: bold;
        }

        .welcome-container p {
            color: #fff;
            font-size: 1.2rem;
            margin-top: 15px;
        }

        .dropdown-submenu {
            position: relative;
        }

        .dropdown-submenu .dropdown-menu {
            top: 0;
            left: 100%;
            margin-left: 0;
        }

        .copyright-footer {
            position: absolute;
            bottom: 20px;
            width: 100%;
            text-align: center;
            color: #f8f9fa;
        }

        .navbar-brand .welcome-admin {
            font-size: 0.9rem;
            margin-left: 15px;
            color: #fff;
            opacity: 0.9;
        }

        .navbar-brand .welcome-admin span {
            font-weight: bold;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
            LoriLah!
            <?php if (isset($_SESSION['admin_name']) || isset($_SESSION['email'])): ?>
                <span class="welcome-admin ms-3">
                    Welcome, 
                    <span>
                        <?= isset($_SESSION['admin_name']) ? htmlspecialchars($_SESSION['admin_name']) : htmlspecialchars($_SESSION['email']) ?>
                    </span>
                </span>
            <?php endif; ?>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>

                <!-- Profile Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        Information
                    </a>
                    <ul class="dropdown-menu">
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">User</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="user.php">Information</a></li>
                                <li><a class="dropdown-item" href="tracktruck.php">Track Truck</a></li>
                            </ul>
                        </li>
                        <li><a class="dropdown-item" href="admin.php">Admin</a></li>
                    </ul>
                </li>

                <li class="nav-item"><a class="nav-link" href="foodtruck.php">Foodtruck</a></li>

                <?php if (isset($_SESSION['email']) || isset($_SESSION['admin_email'])) : ?>
                    <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                <?php else : ?>
                    <li class="nav-item"><a class="nav-link" href="signup.php">Sign Up</a></li>
                    <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<section class="hero text-center">
    <div class="welcome-container">
        <h1>Welcome to LoriLah!</h1>
        <p>Manage food trucks, user data, and reported locations in one dashboard.</p>
    </div>

    <div class="copyright-footer">
        &copy; 2025 LoriLah!. All Rights Reserved.
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Enable Nested Dropdowns -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    var dropdownSubmenus = document.querySelectorAll('.dropdown-submenu');

    dropdownSubmenus.forEach(function (submenu) {
        submenu.addEventListener('mouseenter', function () {
            let subMenu = submenu.querySelector('.dropdown-menu');
            if (subMenu) {
                new bootstrap.Dropdown(subMenu.parentElement); 
                subMenu.classList.add('show');
            }
        });
        submenu.addEventListener('mouseleave', function () {
            let subMenu = submenu.querySelector('.dropdown-menu');
            if (subMenu) {
                subMenu.classList.remove('show');
            }
        });
    });
});
</script>

</body>
</html>
