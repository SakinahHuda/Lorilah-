const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');
const session = require('express-session');

const app = express();
const PORT = 5000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json()); // To handle JSON requests from fetch()

app.use(session({
    secret: 'lorilah_secret_key',
    resave: false,
    saveUninitialized: true
}));

// Serve static files from 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// Setup SQLite Database
const db = new sqlite3.Database('./users.db', (err) => {
    if (err) console.error(err.message);
    console.log('Connected to users database.');
});

// Create tables if not exist
db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT
)`);

db.run(`CREATE TABLE IF NOT EXISTS foodtrucks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    foodType TEXT,
    owner TEXT
)`);

// Insert test user if not exists
db.run('INSERT OR IGNORE INTO users (username, password) VALUES (?, ?)', ['admin', '1234'], (err) => {
    if (err) console.error('Error inserting test user:', err.message);
    else console.log('Test user ready: admin / 1234');
});

// ROUTES

// Home Page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Login Page
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Signup Page
app.get('/signup', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'signup.html'));
});

// Handle Signup
app.post('/signup', (req, res) => {
    const { username, password } = req.body;
    db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, password], (err) => {
        if (err) {
            res.send('<h3>Username already exists or an error occurred.</h3><a href="/signup">Try Again</a>');
        } else {
            res.redirect('/login');  // ✅ Redirect to login after successful signup
        }
    });
});

// Handle login form submission (POST)
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    db.get('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, row) => {
        if (err) {
            res.send('Database error');
        } else if (row) {
            req.session.user = row.username;
            res.redirect('/'); // Redirect to homepage if login successful
        } else {
            res.send('<h3>Invalid username or password.</h3><a href="/login">Try Again</a>');
        }
    });
});

// Logout Route
app.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('http://localhost/lorilah-dashboard/login.html');
});

// ----------------------------
// Foodtruck Backend Routes
// ----------------------------

// Get All Foodtrucks
app.get('/api/foodtrucks', (req, res) => {
    db.all('SELECT * FROM foodtrucks', [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// Add New Foodtruck
app.post('/api/foodtrucks', (req, res) => {
    const { name, foodType, owner } = req.body;
    if (!name || !foodType || !owner) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    db.run('INSERT INTO foodtrucks (name, foodType, owner) VALUES (?, ?, ?)',
        [name, foodType, owner],
        function (err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: 'Foodtruck added successfully', id: this.lastID });
        }
    );
});

// ----------------------------

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
