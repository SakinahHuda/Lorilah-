<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header("Content-Type: application/json");

    // 🟢 Collect POST data
    $user_fullname = trim($_POST['user_fullname'] ?? '');
    $foodtruck_name = trim($_POST['foodtruck_name'] ?? '');
    $foodtype = trim($_POST['foodtype'] ?? ''); 
    $latitude = trim($_POST['latitude'] ?? '');
    $longitude = trim($_POST['longitude'] ?? '');
    $reported_at = trim($_POST['reported_at'] ?? '');
    $created_at = trim($_POST['created_at'] ?? '');

    // 🔴 Validation
    if (
        empty($user_fullname) ||
        empty($foodtruck_name) ||
        empty($foodtype) ||
        empty($latitude) ||
        empty($longitude) ||
        empty($reported_at) ||
        empty($created_at)
    ) {
        echo json_encode(["status" => "error", "message" => "Missing required fields."]);
        exit;
    }

    if (!is_numeric($latitude) || !is_numeric($longitude)) {
        echo json_encode(["status" => "error", "message" => "Latitude and longitude must be numeric."]);
        exit;
    }

    // ✅ Insert into tracktruck
    $stmt = $conn->prepare("
        INSERT INTO tracktruck (user_fullname, foodtruck_name, foodtype, latitude, longitude, reported_at, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => "Database preparation failed."]);
        exit;
    }

    $stmt->bind_param("sssddss", $user_fullname, $foodtruck_name, $foodtype, $latitude, $longitude, $reported_at, $created_at);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Tracking data saved successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to save tracking data."]);
    }

    $stmt->close();
    $conn->close();
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tracked Food Truck Reports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">

<h2>Tracked Food Truck Records</h2>

<?php
// ✅ Show records from tracktruck table
include 'db.php'; // Reopen DB connection
$result = $conn->query("SELECT * FROM tracktruck ORDER BY id ASC");

if ($result && $result->num_rows > 0) {
    echo "<div class='table-responsive'>";
    echo "<table class='table table-bordered table-striped'>";
    echo "<thead class='table-primary'><tr>
            <th>ID</th>
            <th>User Full Name</th>
            <th>Food Truck Name</th>
            <th>Food Type</th>
            <th>Latitude</th>
            <th>Longitude</th>
            <th>Reported At</th>
            <th>Created At</th>
        </tr></thead><tbody>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . htmlspecialchars($row['id']) . "</td>
                <td>" . htmlspecialchars($row['user_fullname']) . "</td>
                <td>" . htmlspecialchars($row['foodtruck_name']) . "</td>
                <td>" . htmlspecialchars($row['foodtype']) . "</td>
                <td>" . htmlspecialchars($row['latitude']) . "</td>
                <td>" . htmlspecialchars($row['longitude']) . "</td>
                <td>" . htmlspecialchars($row['reported_at']) . "</td>
                <td>" . htmlspecialchars($row['created_at']) . "</td>
            </tr>";
    }
    echo "</tbody></table></div>";
} else {
    echo "<div class='alert alert-info'>No tracking records found.</div>";
}

$conn->close();
?>

<div class="mt-4">
    <a href="index.php" class="btn btn-primary">Back to Dashboard</a>
</div>

</body>
</html>
