<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lorilah";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "DB connection failed: " . $conn->connect_error]);
    exit;
}

// Read POST data
$foodtruck_name = $_POST['foodtruck_name'] ?? '';
$foodType = $_POST['foodtype'] ?? '';
$reported_by = $_POST['user_fullname'] ?? '';
$latitude = $_POST['latitude'] ?? '';
$longitude = $_POST['longitude'] ?? '';
$location_description = $_POST['location_description'] ?? '';
$reported_at = $_POST['reported_at'] ?? date("Y-m-d H:i:s");
$created_at = $_POST['created_at'] ?? date("Y-m-d H:i:s");
$address = $_POST['address'] ?? ''; // optional for foodtrucks

// Basic validation
if (empty($foodtruck_name) || empty($latitude) || empty($longitude)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing required fields."]);
    exit;
}

// 1️⃣ Check if foodtruck already exists in `foodtrucks`
$checkSql = "SELECT id FROM foodtrucks WHERE LOWER(TRIM(name)) = LOWER(TRIM(?)) LIMIT 1";
$stmt = $conn->prepare($checkSql);
$stmt->bind_param("s", $foodtruck_name);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    // 2️⃣ Insert into foodtrucks if not exists
    $insertFoodSql = "INSERT INTO foodtrucks (name, foodType, address, latitude, longitude, created_at)
                      VALUES (?, ?, ?, ?, ?, ?)";
    $insertStmt = $conn->prepare($insertFoodSql);
    $insertStmt->bind_param("sssdds", $foodtruck_name, $foodType, $address, $latitude, $longitude, $created_at);
    $insertStmt->execute();
    $insertStmt->close();
}
$stmt->close();

// 3️⃣ Insert report into report_form
$reportSql = "INSERT INTO report_form (foodtruck_name, foodtype, reported_by, latitude, longitude, location_description, reported_at)
              VALUES (?, ?, ?, ?, ?, ?, ?)";
$reportStmt = $conn->prepare($reportSql);
$reportStmt->bind_param("ssssdds", $foodtruck_name, $foodType, $reported_by, $latitude, $longitude, $location_description, $reported_at);

if ($reportStmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Food truck reported successfully."]);
} else {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Failed to insert report."]);
}
$reportStmt->close();
$conn->close();
?>
