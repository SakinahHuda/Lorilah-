<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");

// ✅ Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lorilah";

// ✅ Connect to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Database connection failed: " . $conn->connect_error
    ]);
    exit;
}

// 🔹 Optional filtering by state (if applicable)
$stateFilter = '';
if (!empty($_GET['state'])) {
    $safeState = $conn->real_escape_string($_GET['state']);
    $stateFilter = " WHERE f.state = '$safeState' ";
}

// ✅ SQL Query with JOIN from foodtrucks + latest report info
$sql = "
    SELECT 
        f.id,
        f.name,
        f.foodtype,
        f.address,
        f.latitude,
        f.longitude,
        f.created_at,
        r.latest_reported_at AS lastReportedAt,
        r.latest_reported_by AS reportedBy,
        r.latest_location_desc AS latestLocationDesc
    FROM foodtrucks f
    LEFT JOIN (
        SELECT 
            foodtruck_name,
            MAX(reported_at) AS latest_reported_at,
            SUBSTRING_INDEX(
                GROUP_CONCAT(reported_by ORDER BY reported_at DESC), ',', 1
            ) AS latest_reported_by,
            SUBSTRING_INDEX(
                GROUP_CONCAT(location_description ORDER BY reported_at DESC), ',', 1
            ) AS latest_location_desc
        FROM report_form
        GROUP BY foodtruck_name
    ) r 
    ON REPLACE(LOWER(TRIM(f.name)), ' ', '') = REPLACE(LOWER(TRIM(r.foodtruck_name)), ' ', '')
    $stateFilter
";

// ✅ Execute foodtrucks query
$result = $conn->query($sql);
if (!$result) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "SQL query failed: " . $conn->error
    ]);
    $conn->close();
    exit;
}

// ✅ Collect foodtrucks
$foodtrucks = [];
while ($row = $result->fetch_assoc()) {
    if (!is_null($row["latitude"]) && !is_null($row["longitude"])) {
        $foodtrucks[] = [
            "id" => (int)$row["id"],
            "name" => $row["name"], // official foodtruck name
            "foodType" => $row["foodtype"],
            "address" => $row["address"],
            "latitude" => (float)$row["latitude"],
            "longitude" => (float)$row["longitude"],
            "createdAt" => $row["created_at"] ?? "Unknown",
            "lastReportedAt" => $row["lastReportedAt"] ?? "N/A",
            "reportedBy" => $row["reportedBy"] ?? "Unknown",
            "latestLocationDesc" => $row["latestLocationDesc"] ?? "N/A",
            "source" => "official"
        ];
    }
}

// ✅ Additional: report_form-only entries (not in foodtrucks)
$reportQuery = "
    SELECT 
        NULL AS id,
        reported_by AS name,  -- 🔁 Use reporter name as marker title
        foodType,
        '-' AS address,
        latitude,
        longitude,
        reported_at AS createdAt,
        reported_at AS lastReportedAt,
        reported_by AS reportedBy,
        location_description AS latestLocationDesc
    FROM report_form
    WHERE REPLACE(LOWER(TRIM(foodtruck_name)), ' ', '') NOT IN (
        SELECT REPLACE(LOWER(TRIM(name)), ' ', '') FROM foodtrucks
    )
";

// ✅ Execute report_form query
$reportResult = $conn->query($reportQuery);
if ($reportResult) {
    while ($row = $reportResult->fetch_assoc()) {
        if (!is_null($row["latitude"]) && !is_null($row["longitude"])) {
            $foodtrucks[] = [
                "id" => null,
                "name" => $row["name"], // reporter name as title
                "foodType" => $row["foodType"],
                "address" => $row["address"],
                "latitude" => (float)$row["latitude"],
                "longitude" => (float)$row["longitude"],
                "createdAt" => $row["createdAt"] ?? "Unknown",
                "lastReportedAt" => $row["lastReportedAt"] ?? "N/A",
                "reportedBy" => $row["reportedBy"] ?? "Unknown",
                "latestLocationDesc" => $row["latestLocationDesc"] ?? "N/A",
                "source" => "user"
            ];
        }
    }
}

// ✅ Send JSON result
echo json_encode([
    "status" => "success",
    "data" => $foodtrucks,
    "message" => count($foodtrucks) > 0
        ? "Food trucks retrieved successfully (from both tables)."
        : "No food trucks found."
], JSON_UNESCAPED_UNICODE);

$conn->close();
?>
