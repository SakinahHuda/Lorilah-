<?php
header("Content-Type: application/json");

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lorilah";

// Google Maps Geocoding API Key
$googleApiKey = "AIzaSyCrDfjPdZvlPCMgCVOeNnJeu3mvaDO_0nM";

// DB Connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed."]);
    exit;
}

// Collect POST data
$foodtruck_name = trim($_POST['name'] ?? '');
$foodtruck_type = trim($_POST['type'] ?? '');
$location_description = trim($_POST['location_desc'] ?? '');
$state = trim($_POST['state'] ?? '');
$reported_at = trim($_POST['reported_at'] ?? '');
$reported_by = trim($_POST['reported_by'] ?? '');

// ✅ Log incoming POST data (for debugging)
file_put_contents("debug_post.txt", json_encode($_POST));

// ✅ Collect latitude & longitude if sent from Android
$latitude = isset($_POST['latitude']) ? floatval($_POST['latitude']) : null;
$longitude = isset($_POST['longitude']) ? floatval($_POST['longitude']) : null;

// ✅ If not sent, fallback to geocoding based on state
if (!$latitude || !$longitude) {
    $full_address = urlencode($state);
    $geocodeUrl = "https://maps.googleapis.com/maps/api/geocode/json?address=$full_address&key=$googleApiKey";
    $geoResponse = file_get_contents($geocodeUrl);
    $geoData = json_decode($geoResponse, true);

    // 🔍 Log raw API response
    file_put_contents("debug_geocode.txt", $geoResponse);

    if (!$geoData || $geoData['status'] !== 'OK') {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "Unable to geocode the address.",
            "google_status" => $geoData['status'] ?? 'no_response',
            "address_sent" => urldecode($full_address)
        ]);
        exit;
    }

    // ✅ Extract and log fallback lat/lng
    $latitude = $geoData['results'][0]['geometry']['location']['lat'];
    $longitude = $geoData['results'][0]['geometry']['location']['lng'];

    file_put_contents("geocoded_log.txt", json_encode([
        "input" => urldecode($full_address),
        "lat" => $latitude,
        "lng" => $longitude,
        "timestamp" => date("Y-m-d H:i:s")
    ]) . PHP_EOL, FILE_APPEND);
}

// 🔸 Insert into report_form (use correct column names)
$stmtForm = $conn->prepare("
    INSERT INTO report_form 
    (foodtruck_name, foodType, location_description, state, latitude, longitude, reported_at, reported_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
");

if (!$stmtForm) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Insert into report_form failed: " . $conn->error]);
    exit;
}

$stmtForm->bind_param("ssssddss", $foodtruck_name, $foodtruck_type, $location_description, $state, $latitude, $longitude, $reported_at, $reported_by);

if (!$stmtForm->execute()) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Insert failed", "sql_error" => $stmtForm->error]);
    $stmtForm->close();
    exit;
}
$stmtForm->close();

// 🔹 Insert or update foodtrucks
$success = false;
$checkExist = $conn->prepare("SELECT id FROM foodtrucks WHERE name = ?");
$checkExist->bind_param("s", $foodtruck_name);
$checkExist->execute();
$checkExist->store_result();

if ($checkExist->num_rows > 0) {
    $update = $conn->prepare("
        UPDATE foodtrucks 
        SET foodType = ?, address = ?, state = ?, latitude = ?, longitude = ?, lastReportedAt = ?, reportedBy = ?
        WHERE name = ?
    ");
    $update->bind_param("ssssddss", $foodtruck_type, $location_description, $state, $latitude, $longitude, $reported_at, $reported_by, $foodtruck_name);
    $success = $update->execute();
    $update->close();
} else {
    $insert = $conn->prepare("
        INSERT INTO foodtrucks 
        (name, foodType, address, state, latitude, longitude, lastReportedAt, reportedBy, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    $insert->bind_param("ssssddss", $foodtruck_name, $foodtruck_type, $location_description, $state, $latitude, $longitude, $reported_at, $reported_by);
    $success = $insert->execute();
    $insert->close();
}
$checkExist->close();

// ✅ Final response
if ($success) {
    echo json_encode(["status" => "success", "message" => "Report submitted and map updated."]);
} else {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Map update failed."]);
}

$conn->close();
?>
