<?php
// Return plain text to Android app
header("Content-Type: text/plain");

// TEMP: Debug incoming POST data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST)) {
        echo "No POST data received.\n";
        exit;
    }
} else {
    echo "Request method is not POST.";
    exit;
}

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lorilah";

// Connect to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed.");
}

// Retrieve and sanitize input
$fullname = trim($_POST['fullname'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');
$address = trim($_POST['address'] ?? '');

// Check required fields
if (empty($fullname) || empty($email) || empty($password) || empty($address)) {
    echo "All fields are required.";
    exit;
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email format.";
    exit;
}

// Hash the password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Check if email already exists
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo "Email already registered.";
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->close();

// Geocode address using Google Maps API
$apiKey = "AIzaSyD2cmnlJ-URB99rPfLKsLqn2qpj-cYTELU"; 
$addressEncoded = urlencode($address);
$geocodeUrl = "https://maps.googleapis.com/maps/api/geocode/json?address=$addressEncoded&key=$apiKey";

$response = @file_get_contents($geocodeUrl);
$responseData = json_decode($response, true);

// Handle geocoding result
if ($responseData && $responseData['status'] === 'OK') {
    $latitude = $responseData['results'][0]['geometry']['location']['lat'];
    $longitude = $responseData['results'][0]['geometry']['location']['lng'];
} else {
    $latitude = null;
    $longitude = null;
}

// Insert user into DB
$stmt = $conn->prepare("INSERT INTO users (fullname, email, password, address, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssdd", $fullname, $email, $hashedPassword, $address, $latitude, $longitude);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "An error occurred. Please try again.";
}

$stmt->close();
$conn->close();
?>
