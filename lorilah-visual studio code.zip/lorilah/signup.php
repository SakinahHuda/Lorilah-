<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'db.php';
session_start();

$success = "";
$error = "";

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Basic validation
    if (empty($name) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Check if email already exists in admin table
        $stmt = $conn->prepare("SELECT id FROM admin WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Email already registered as an admin.";
        } else {
            $stmt->close();

            // Insert new admin
            $stmt = $conn->prepare("INSERT INTO admin (name, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $email, $hashedPassword);

            if ($stmt->execute()) {
                // Redirect to login with full name and password in URL for auto-fill
                header("Location: login.php?name=" . urlencode($name) . "&password=" . urlencode($password));
                exit;
            } else {
                $error = "An error occurred. Please try again.";
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Sign Up - LoriLah!</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            padding: 0;
        }

        .background {
            background: url('loginfoodtruck.jpg') center center/cover no-repeat;
            height: 100%;
            width: 100%;
            position: absolute;
            top: 0;
            left: 0;
            z-index: -1;
        }

        .signup-container {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .signup-form {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.3);
            max-width: 400px;
            width: 100%;
        }
    </style>
</head>
<body>

<div class="background"></div>

<div class="container signup-container">
    <div class="signup-form">
        <h2 class="text-center mb-4">Admin Sign Up for <span class="text-success">LoriLah!</span></h2>

        <?php if (!empty($error)) { echo "<div class='alert alert-danger'>" . htmlspecialchars($error) . "</div>"; } ?>
        <?php if (!empty($success)) { echo "<div class='alert alert-success'>" . htmlspecialchars($success) . "</div>"; } ?>

        <form action="signup.php" method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">Full Name</label>
                <input name="name" id="name" class="form-control" placeholder="Enter Full Name" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input name="email" id="email" type="email" class="form-control" placeholder="Enter email" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input name="password" id="password" type="password" class="form-control" placeholder="Enter password" required>
            </div>

            <button type="submit" class="btn btn-success w-100">Register Admin</button>
        </form>
    </div>
</div>

</body>
</html>
