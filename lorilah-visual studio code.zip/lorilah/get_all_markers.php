<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lorilah";

// DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
    exit;
}

// Get food trucks
$foodtrucks = [];
$truckQuery = "SELECT * FROM foodtrucks WHERE latitude IS NOT NULL AND longitude IS NOT NULL";
$truckResult = $conn->query($truckQuery);

if ($truckResult) {
    while ($row = $truckResult->fetch_assoc()) {
        $foodtrucks[] = [
            "source" => "foodtruck",
            "name" => $row["name"] ?? "Unnamed Truck",
            "foodType" => (!empty($row["foodtype"])) ? $row["foodtype"] : "Not specified",
            "address" => (!empty($row["address"])) ? $row["address"] : "No address",
            "latitude" => isset($row["latitude"]) ? (float)$row["latitude"] : 0,
            "longitude" => isset($row["longitude"]) ? (float)$row["longitude"] : 0,
            "reportedBy" => "Owner",
            "lastReportedAt" => (!empty($row["created_at"])) ? $row["created_at"] : ""
        ];
    }
} else {
    echo json_encode(["status" => "error", "message" => "Query failed: " . $conn->error]);
    exit;
}

// Get public reports
$reports = [];
$reportQuery = "SELECT * FROM report_form WHERE latitude IS NOT NULL AND longitude IS NOT NULL";
$reportResult = $conn->query($reportQuery);

if ($reportResult) {
    while ($row = $reportResult->fetch_assoc()) {
        $reports[] = [
            "source" => "report",
            "name" => $row["foodtruck_name"] ?? "Unknown",
            "foodType" => (!empty($row["foodtruck_type"])) ? $row["foodtruck_type"] : "Not specified",
            "address" => (!empty($row["location_description"])) ? $row["location_description"] : "No location",
            "latitude" => isset($row["latitude"]) ? (float)$row["latitude"] : 0,
            "longitude" => isset($row["longitude"]) ? (float)$row["longitude"] : 0,
            "reportedBy" => (!empty($row["reported_by"])) ? $row["reported_by"] : "Anonymous",
            "lastReportedAt" => (!empty($row["reported_at"])) ? $row["reported_at"] : ""
        ];
    }
} else {
    echo json_encode(["status" => "error", "message" => "Report query failed: " . $conn->error]);
    exit;
}

$conn->close();

// Merge and output
$allMarkers = array_merge($foodtrucks, $reports);
echo json_encode(["status" => "success", "data" => $allMarkers], JSON_UNESCAPED_UNICODE);
