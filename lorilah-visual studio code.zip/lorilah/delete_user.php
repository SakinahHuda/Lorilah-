<?php
include 'db.php';
session_start();

if (!isset($_GET['id'])) {
    header("Location: user.php");
    exit();
}

$id = intval($_GET['id']);

// Delete user
$conn->query("DELETE FROM users WHERE id = $id");

header("Location: user.php");
exit();
?>
