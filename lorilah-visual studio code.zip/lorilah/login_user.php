<?php
header("Content-Type: application/json; charset=UTF-8");

// ✅ Database Configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lorilah";

// ✅ Create Database Connection
$conn = new mysqli($servername, $username, $password, $dbname);

// ❌ If Connection Fails
if ($conn->connect_error) {
    echo json_encode([
        "status" => "error",
        "message" => "Database connection failed."
    ]);
    exit;
}

// ✅ Retrieve Input Data from POST or REQUEST
$email = trim($_REQUEST['email'] ?? '');
$password = trim($_REQUEST['password'] ?? '');

// ✅ Validate Inputs
if (empty($email) || empty($password)) {
    echo json_encode([
        "status" => "error",
        "message" => "Missing required parameters (email and password)."
    ]);
    exit;
}

// ✅ Prepare SQL Statement
$stmt = $conn->prepare("SELECT fullname, email, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

// ✅ Check if User Exists
if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();

    // ✅ Verify Password
    if (password_verify($password, $user['password'])) {
        echo json_encode([
            "status" => "success",
            "fullname" => $user['fullname'],
            "email" => $user['email']
        ]);
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Invalid email or password."
        ]);
    }
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid email or password."
    ]);
}

// ✅ Close Connections
$stmt->close();
$conn->close();
?>
