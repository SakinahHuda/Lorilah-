<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "lorilah";

$googleApiKey = "AIzaSyCrDfjPdZvlPCMgCVOeNnJeu3mvaDO_0nM"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("<script>alert('Database connection failed.'); window.location.href='foodtruck.php';</script>");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $truckName = trim($_POST['truckName']);
    $foodType = trim($_POST['foodtype']);
    $owner = trim($_POST['owner']);
    $address = trim($_POST['address']);

    if (empty($truckName) || empty($foodType) || empty($owner) || empty($address)) {
        echo "<script>alert('All fields are required.'); window.location.href='foodtruck.php?action=add';</script>";
        exit;
    }

    // Get coordinates using Google Maps Geocoding API
    $addressEncoded = urlencode($address);
    $geoUrl = "https://maps.googleapis.com/maps/api/geocode/json?address={$addressEncoded}&key={$googleApiKey}";

    $geoResponse = file_get_contents($geoUrl);
    $geoData = json_decode($geoResponse, true);

    if ($geoData['status'] === 'OK') {
        $latitude = $geoData['results'][0]['geometry']['location']['lat'];
        $longitude = $geoData['results'][0]['geometry']['location']['lng'];
    } else {
        echo "<script>alert('Failed to get coordinates for the address. Please check the address.'); window.location.href='foodtruck.php?action=add';</script>";
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO foodtrucks (name, foodtype, owner, address, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssdd", $truckName, $foodType, $owner, $address, $latitude, $longitude);

    if ($stmt->execute()) {
        header("Location: foodtruck.php?action=view");
        exit;
    } else {
        echo "<script>alert('Error adding foodtruck.'); window.location.href='foodtruck.php?action=add';</script>";
    }

    $stmt->close();
} else {
    header("Location: foodtruck.php");
    exit;
}

$conn->close();
?>
