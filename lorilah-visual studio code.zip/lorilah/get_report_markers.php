<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lorilah";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]);
    exit;
}

$sql = "
    SELECT 
        foodtruck_name AS name,
        foodtruck_type AS foodType,
        location_desc AS address,
        latitude,
        longitude,
        reported_at,
        reported_by
    FROM report_form
    WHERE latitude IS NOT NULL AND longitude IS NOT NULL
";

$result = $conn->query($sql);

$foodtrucks = [];

while ($row = $result->fetch_assoc()) {
    $foodtrucks[] = [
        "name" => $row["name"],
        "foodType" => $row["foodType"],
        "address" => $row["address"],
        "latitude" => (float)$row["latitude"],
        "longitude" => (float)$row["longitude"],
        "lastReportedAt" => $row["reported_at"],
        "reportedBy" => $row["reported_by"]
    ];
}

echo json_encode(["status" => "success", "data" => $foodtrucks], JSON_UNESCAPED_UNICODE);

$conn->close();
?>
