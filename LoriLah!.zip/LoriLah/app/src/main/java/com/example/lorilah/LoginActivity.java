package com.example.lorilah;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private EditText emailInput, passwordInput;

    private static final String LOGIN_URL = "http://172.22.192.1/lorilah/login_user.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initViews();
        setupClickListeners();
    }

    private void initViews() {
        emailInput = findViewById(R.id.email_input);
        passwordInput = findViewById(R.id.password_input);
    }

    private void setupClickListeners() {
        findViewById(R.id.btn_login).setOnClickListener(v -> handleLogin());
        findViewById(R.id.btn_signup).setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, SignupActivity.class));
            finish();
        });
    }

    private void handleLogin() {
        String email = emailInput.getText() != null ? emailInput.getText().toString().trim() : "";
        String password = passwordInput.getText() != null ? passwordInput.getText().toString().trim() : "";

        if (email.isEmpty()) {
            emailInput.setError("Email is required");
            return;
        }
        if (password.isEmpty()) {
            passwordInput.setError("Password is required");
            return;
        }

        if (email.equals("admin@example.com") && password.equals("admin123")) {
            saveSession(email, "Admin");
            Toast.makeText(this, "Admin login successful (App Only)", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MapsActivity.class));
            finish();
        } else {
            userLogin(email, password);
        }
    }

    private void userLogin(String email, String password) {
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest request = new StringRequest(Request.Method.POST, LOGIN_URL,
                response -> {
                    Log.d("LoginDebug", "Server Response: " + response);
                    try {
                        JSONObject json = new JSONObject(response);

                        if (json.has("status") && json.getString("status").equalsIgnoreCase("success")) {
                            String fullname = json.optString("fullname", "User");

                            saveSession(email, fullname);

                            Toast.makeText(this, "User login successful", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(this, MainActivity.class));
                            finish();
                        } else {
                            String message = json.optString("message", "Login failed");
                            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Log.e("LoginDebug", "Error parsing server response", e);
                        Toast.makeText(this, "Error parsing server response", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Log.e("LoginDebug", "Network error", error);
                    Toast.makeText(this, "Network error. Check your connection.", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("email", email);
                params.put("password", password);
                return params;
            }
        };

        queue.add(request);
    }

    private void saveSession(String email, String fullname) {
        SharedPreferences prefs = getSharedPreferences("userSession", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("email", email);
        editor.putString("fullname", fullname); // Save full name as "fullname"
        editor.apply();
    }
}
