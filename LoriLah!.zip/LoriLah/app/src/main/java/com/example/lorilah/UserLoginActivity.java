package com.example.lorilah;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UserLoginActivity extends AppCompatActivity {

    private TextInputEditText etEmail, etPassword;
    private Button btnLogin, btnSignup;

    private static final String LOGIN_URL = "http://172.22.192.1/lorilah/login_user.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);

        // ✅ Use correct IDs from your XML layout
        etEmail = findViewById(R.id.email_input);
        etPassword = findViewById(R.id.password_input);
        btnLogin = findViewById(R.id.btn_login);
        btnSignup = findViewById(R.id.btn_signup);

        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty()) {
                etEmail.setError("Email is required");
                return;
            }

            if (password.isEmpty()) {
                etPassword.setError("Password is required");
                return;
            }

            loginUser(email, password);
        });

        btnSignup.setOnClickListener(v -> {
            startActivity(new Intent(UserLoginActivity.this, SignupActivity.class));
        });
    }

    private void loginUser(String email, String password) {
        StringRequest request = new StringRequest(Request.Method.POST, LOGIN_URL,
                response -> {
                    Log.d("LoginResponse", response);

                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String status = jsonObject.getString("status");

                        if (status.equalsIgnoreCase("success")) {
                            String fullname = jsonObject.getString("fullname");

                            Toast.makeText(this, "Login successful! Welcome, " + fullname, Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(this, MainActivity.class); // ✅ change to your dashboard activity if needed
                            intent.putExtra("fullname", fullname);
                            intent.putExtra("email", jsonObject.getString("email"));
                            startActivity(intent);
                            finish();

                        } else {
                            String message = jsonObject.optString("message", "Login failed");
                            Toast.makeText(this, "Login failed: " + message, Toast.LENGTH_LONG).show();
                        }

                    } catch (JSONException e) {
                        Log.e("LoginError", "JSON parse error", e);
                        Toast.makeText(this, "Response parsing error", Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    Log.e("LoginError", "Volley error", error);
                    Toast.makeText(this, "Network error. Please check your connection.", Toast.LENGTH_LONG).show();
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("email", email);
                params.put("password", password);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }
}
