package com.example.lorilah;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.*;

import java.text.SimpleDateFormat;
import java.util.*;

public class ReportFoodTruckActivity extends AppCompatActivity {

    private EditText etName, etType, etState, etLocationDesc;
    private TextView tvDateTime;
    private Button btnSubmit, btnBack;

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;
    private static final String SUBMIT_URL = "http://172.22.192.1/lorilah/submit_foodtruck.php";

    private FusedLocationProviderClient fusedLocationClient;
    private double latitude = 0.0;
    private double longitude = 0.0;
    private boolean locationAcquired = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_foodtruck);

        // 🔧 Initialize views
        etName = findViewById(R.id.et_foodtruck_name);
        etType = findViewById(R.id.et_foodtruck_type);
        etState = findViewById(R.id.et_state);
        etLocationDesc = findViewById(R.id.et_location_desc);
        tvDateTime = findViewById(R.id.tv_date_time);
        btnSubmit = findViewById(R.id.btn_submit);
        btnBack = findViewById(R.id.btn_back);

        // current date and time
        updateCurrentDateTime();

        // location
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        requestLocationPermission();

        // Submit form
        btnSubmit.setOnClickListener(v -> {
            if (locationAcquired) {
                submitReport();
            } else {
                Toast.makeText(this, "Waiting for GPS... Please wait until location is acquired.", Toast.LENGTH_LONG).show();
                getLastLocation(); // retry
            }
        });

        // Back to MainActivity
        btnBack.setOnClickListener(v -> {
            startActivity(new Intent(ReportFoodTruckActivity.this, MainActivity.class));
            finish();
        });
    }

    private void updateCurrentDateTime() {
        String currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        tvDateTime.setText(currentTime);
    }

    private void requestLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            getLastLocation();
        }
    }

    private void getLastLocation() {
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, location -> {
                    if (location != null) {
                        latitude = location.getLatitude();
                        longitude = location.getLongitude();
                        locationAcquired = true;
                        Log.d("LOCATION", "Lat: " + latitude + ", Lng: " + longitude);
                        Toast.makeText(this, "Location acquired.", Toast.LENGTH_SHORT).show();
                    } else {
                        Log.d("LOCATION", "Last location is null, requesting updates...");
                        requestSingleLocationUpdate();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to get location: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    requestSingleLocationUpdate();
                });
    }

    private void requestSingleLocationUpdate() {
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setPriority(Priority.PRIORITY_HIGH_ACCURACY);
        locationRequest.setNumUpdates(1);
        locationRequest.setInterval(1000);

        LocationCallback locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                Location location = locationResult.getLastLocation();
                if (location != null) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                    locationAcquired = true;
                    Log.d("LOCATION", "Lat (update): " + latitude + ", Lng: " + longitude);
                    Toast.makeText(ReportFoodTruckActivity.this, "Location updated.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ReportFoodTruckActivity.this, "Location update failed.", Toast.LENGTH_SHORT).show();
                }
            }
        };

        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLastLocation();
            } else {
                Toast.makeText(this, "Location permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void submitReport() {
        String name = etName.getText().toString().trim();
        String type = etType.getText().toString().trim();
        String state = etState.getText().toString().trim();
        String locationDesc = etLocationDesc.getText().toString().trim();
        String dateTime = tvDateTime.getText().toString().trim();

        SharedPreferences prefs = getSharedPreferences("userSession", MODE_PRIVATE);
        String reporter = prefs.getString("fullname", "Anonymous");

        if (name.isEmpty() || type.isEmpty() || state.isEmpty() || locationDesc.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!locationAcquired || latitude == 0.0 || longitude == 0.0) {
            Toast.makeText(this, "GPS not ready. Please wait and try again.", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest request = new StringRequest(Request.Method.POST, SUBMIT_URL,
                response -> {
                    Toast.makeText(this, "Food Truck reported!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(ReportFoodTruckActivity.this, MapsActivity.class));
                    finish();
                },
                error -> {
                    Log.e("SUBMIT", "Volley error: " + error.getMessage());
                    Toast.makeText(this, "Failed to submit report", Toast.LENGTH_SHORT).show();
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("name", name);
                params.put("type", type);
                params.put("state", state);
                params.put("location_desc", locationDesc);
                params.put("reported_at", dateTime);
                params.put("reported_by", reporter);
                params.put("latitude", String.valueOf(latitude));
                params.put("longitude", String.valueOf(longitude));
                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }
}
