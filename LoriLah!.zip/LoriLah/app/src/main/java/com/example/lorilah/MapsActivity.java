package com.example.lorilah;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.lorilah.databinding.ActivityMapsBinding;
import com.google.android.gms.maps.*;
import com.google.android.gms.maps.model.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.*;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    private Geocoder geocoder;

    private static final String FOODTRUCKS_URL = "http://172.22.192.1/lorilah/get_foodtrucks.php";
    private static final String TRACKTRUCK_URL = "http://172.22.192.1/lorilah/tracktruck.php";
    private static final String LIVE_REPORT_URL = "http://172.22.192.1/lorilah/get_latest_report.php";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    private final Map<Marker, String> markerMenuMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        geocoder = new Geocoder(this, Locale.getDefault());

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        } else {
            Toast.makeText(this, "Map fragment not found", Toast.LENGTH_SHORT).show();
        }

        binding.backButton.setOnClickListener(v -> finish());
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (mMap == null) {
            Toast.makeText(this, "Map failed to load", Toast.LENGTH_SHORT).show();
            return;
        }

        enableUserLocation();
        loadFoodTruckMarkers();

        mMap.setOnInfoWindowClickListener(this::fetchAndShowLiveReport);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mMap != null) {
            mMap.clear();
            loadFoodTruckMarkers();
        }
    }

    private void enableUserLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    private void loadFoodTruckMarkers() {
        RequestQueue queue = Volley.newRequestQueue(this);
        String urlWithTimestamp = FOODTRUCKS_URL + "?t=" + System.currentTimeMillis();

        StringRequest request = new StringRequest(Request.Method.GET, urlWithTimestamp,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if ("success".equals(json.optString("status"))) {
                            JSONArray data = json.optJSONArray("data");
                            if (data == null) return;

                            LatLngBounds.Builder builder = new LatLngBounds.Builder();

                            for (int i = 0; i < data.length(); i++) {
                                JSONObject foodtruck = data.optJSONObject(i);
                                if (foodtruck == null) continue;

                                double lat = foodtruck.optDouble("latitude", 0);
                                double lng = foodtruck.optDouble("longitude", 0);
                                String name = foodtruck.optString("name", "Unknown");

                                if (lat == 0 && lng == 0) continue;

                                String foodType = foodtruck.optString("foodType", "Menu not available");

                                LatLng location = new LatLng(lat, lng);
                                int iconRes = getMarkerIcon(name);

                                Marker marker = mMap.addMarker(new MarkerOptions()
                                        .position(location)
                                        .title(name)
                                        .snippet("Tap to view menu")
                                        .icon(resizeIcon(iconRes, 50, 50))
                                );

                                markerMenuMap.put(marker, foodType);
                                builder.include(location);
                            }

                            if (data.length() > 0) {
                                LatLngBounds bounds = builder.build();
                                int padding = 100;
                                mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, padding));
                            }
                        } else {
                            Toast.makeText(this, "Failed to load food trucks", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Log.e("MapsActivity", "JSON parse error", e);
                        Toast.makeText(this, "Error loading data", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Log.e("MapsActivity", "Network error", error);
                    Toast.makeText(this, "Network error: " + error.getMessage(), Toast.LENGTH_LONG).show();
                });

        request.setShouldCache(false);
        queue.add(request);
    }

    private void fetchAndShowLiveReport(Marker marker) {
        String foodtruckName = marker.getTitle();
        String rawMenu = markerMenuMap.get(marker);
        LatLng location = marker.getPosition();

        String finalMenu = (rawMenu == null || rawMenu.isEmpty()) ? "Menu not available" : rawMenu;
        String url = LIVE_REPORT_URL + "?name=" + Uri.encode(foodtruckName);

        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        String reportedBy = json.optString("reported_by", "Unknown");
                        String lastReported = json.optString("reported_at", "N/A");

                        String message = finalMenu +
                                "\n\nLast Reported: " + lastReported +
                                "\nReported By: " + reportedBy;

                        new androidx.appcompat.app.AlertDialog.Builder(MapsActivity.this)
                                .setTitle(foodtruckName)
                                .setMessage(message)
                                .setPositiveButton("OK", (dialog, which) ->
                                        sendTrackData(foodtruckName, finalMenu, location.latitude, location.longitude))
                                .show();

                    } catch (Exception e) {
                        Log.e("LiveReport", "Parsing error", e);
                    }
                },
                error -> {
                    Log.e("LiveReport", "Network error", error);
                    Toast.makeText(this, "Error fetching report info", Toast.LENGTH_SHORT).show();
                });

        queue.add(request);
    }

    private void sendTrackData(String foodtruckName, String foodType, double lat, double lng) {
        SharedPreferences prefs = getSharedPreferences("userSession", MODE_PRIVATE);
        String fullname = prefs.getString("fullname", null);

        if (fullname == null) {
            Toast.makeText(this, "Please login again to track food trucks.", Toast.LENGTH_SHORT).show();
            return;
        }

        String currentDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest request = new StringRequest(Request.Method.POST, TRACKTRUCK_URL,
                response -> {
                    Log.d("TrackTruck", "Track recorded: " + response);
                    Toast.makeText(this, "Food Truck location tracked!", Toast.LENGTH_SHORT).show();
                },
                error -> {
                    Log.e("TrackTruck", "Error sending track data", error);
                    Toast.makeText(this, "Error tracking food truck", Toast.LENGTH_SHORT).show();
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_fullname", fullname);
                params.put("foodtype", foodType);
                params.put("foodtruck_name", foodtruckName);
                params.put("latitude", String.valueOf(lat));
                params.put("longitude", String.valueOf(lng));
                params.put("reported_at", currentDateTime);
                params.put("created_at", currentDateTime);
                return params;
            }
        };

        queue.add(request);
    }

    private int getMarkerIcon(String name) {
        return R.drawable.location;
    }

    private BitmapDescriptor resizeIcon(int resId, int width, int height) {
        Bitmap imageBitmap = BitmapFactory.decodeResource(getResources(), resId);
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(imageBitmap, width, height, false);
        return BitmapDescriptorFactory.fromBitmap(resizedBitmap);
    }

    private void searchLocation(String locationName) {
        try {
            List<Address> addresses = geocoder.getFromLocationName(locationName, 1);
            if (addresses == null || addresses.isEmpty()) {
                Toast.makeText(this, "Location not found", Toast.LENGTH_SHORT).show();
                return;
            }

            Address address = addresses.get(0);
            LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
        } catch (Exception e) {
            Log.e("MapsActivity", "Error searching location", e);
            Toast.makeText(this, "Error finding location", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                if (mMap != null) {
                    mMap.setMyLocationEnabled(true);
                }
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
