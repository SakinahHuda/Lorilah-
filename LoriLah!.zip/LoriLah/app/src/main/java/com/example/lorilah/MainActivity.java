package com.example.lorilah;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView greetingText;
    private Button viewMapButton, aboutButton, profileButton, reportFoodTruckButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        greetingText = findViewById(R.id.greeting_text);
        viewMapButton = findViewById(R.id.btn_view_map);
        aboutButton = findViewById(R.id.about_button);
        profileButton = findViewById(R.id.profile_button);
        reportFoodTruckButton = findViewById(R.id.btn_report_foodtruck);

        // Load user session
        SharedPreferences prefs = getSharedPreferences("userSession", MODE_PRIVATE);
        String fullname = prefs.getString("fullname", "User");
        greetingText.setText("Hi, " + fullname + "!");

        // View Map Button Action
        viewMapButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MapsActivity.class);
            startActivity(intent);
        });

        // About Button Action
        aboutButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(intent);
        });

        // Profile Button Action
        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
            startActivity(intent);
        });

        // Report Food Truck Button Action
        reportFoodTruckButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ReportFoodTruckActivity.class);
            startActivity(intent);
        });
    }
}
