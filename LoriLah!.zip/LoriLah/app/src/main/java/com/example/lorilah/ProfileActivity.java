package com.example.lorilah;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private EditText etUsername, etEmail, etPassword;
    private Button btnLogout, btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Bind UI elements
        etUsername = findViewById(R.id.et_username);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        btnLogout = findViewById(R.id.btn_logout);
        btnBack = findViewById(R.id.btn_back_profile);

        etUsername.setEnabled(false);
        etEmail.setEnabled(false);
        etPassword.setEnabled(false);

        SharedPreferences prefs = getSharedPreferences("userSession", MODE_PRIVATE);
        String fullname = prefs.getString("fullname", "N/A");
        String email = prefs.getString("email", "N/A");

        // Display data
        etUsername.setText(fullname);
        etEmail.setText(email);
        etPassword.setText("********");

        // Logout button
        btnLogout.setOnClickListener(v -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear();
            editor.apply();

            Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        // Back button
        btnBack.setOnClickListener(v -> {
            Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
