package com.example.lorilah;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class FoodtruckAdapter extends ArrayAdapter<Foodtruck> {

    public FoodtruckAdapter(Context context, ArrayList<Foodtruck> foodtrucks) {
        super(context, 0, foodtrucks);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        Foodtruck truck = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.foodtruck_item, parent, false);
        }

        TextView nameText = convertView.findViewById(R.id.nameText);
        TextView locationText = convertView.findViewById(R.id.locationText);

        if (truck != null) {
            nameText.setText(truck.name + " (" + truck.foodType + ")");
            locationText.setText("Lat: " + truck.latitude + ", Lng: " + truck.longitude);
        }

        return convertView;
    }
}
