package com.example.lorilah;

public class Foodtruck {
    String name, foodType, owner;
    double latitude, longitude;

    public Foodtruck(String name, String foodType, String owner, double latitude, double longitude) {
        this.name = name;
        this.foodType = foodType;
        this.owner = owner;
        this.latitude = latitude;
        this.longitude = longitude;
    }
}
