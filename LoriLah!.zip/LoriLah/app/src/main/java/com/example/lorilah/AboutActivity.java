package com.example.lorilah;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        // 1. Make GitHub link clickable
//        TextView githubLink = findViewById(R.id.github_link);
//        githubLink.setOnClickListener(v -> {
//            Intent browserIntent = new Intent(
//                    Intent.ACTION_VIEW,
//                    Uri.parse("https://github.com/your-team/lorilah") // Replace with your GitHub URL
//            );
//            startActivity(browserIntent);
//        });
//
//        // 2. (Optional) Add back button to return to MainActivity
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }
}