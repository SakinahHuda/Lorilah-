package com.example.lorilah;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class FoodtruckListActivity extends AppCompatActivity {

    private ListView listView;
    private FoodtruckAdapter adapter;
    private ArrayList<Foodtruck> foodtruckList = new ArrayList<>();

    private static final String URL = "http://172.22.192.1/lorilah/fetch_foodtrucks.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foodtruck_list);

        listView = findViewById(R.id.listView);
        adapter = new FoodtruckAdapter(this, foodtruckList);
        listView.setAdapter(adapter);

        fetchFoodtrucks();
    }

    private void fetchFoodtrucks() {
        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, URL, null,
                response -> {
                    try {
                        JSONArray data = response.getJSONArray("data");
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject truck = data.getJSONObject(i);
                            String name = truck.getString("name");
                            String foodType = truck.getString("foodType");
                            String owner = truck.getString("owner");
                            double latitude = truck.getDouble("latitude");
                            double longitude = truck.getDouble("longitude");

                            foodtruckList.add(new Foodtruck(name, foodType, owner, latitude, longitude));
                        }
                        adapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        Toast.makeText(this, "Error parsing data", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }
                },
                error -> {
                    Toast.makeText(this, "Failed to fetch data", Toast.LENGTH_SHORT).show();
                    error.printStackTrace();
                });

        queue.add(request);
    }
}
